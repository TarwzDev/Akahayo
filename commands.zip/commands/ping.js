module.exports = {


    run: async (client, message, args) => {

        const m = await message.channel.send(`Ping?...`);
        m.edit(`:stopwatch:| Gateway Ping: ${m.createdTimestamp - message.createdTimestamp}ms. \n:zap:| API ping: ${Math.round(client.ping)}ms.`)

    },

    conf: {},

    help: {
      name: 'ping',
      aliases: ['ping'],
      category: 'ping',
      description: 'Mostra a latência ',
      usage: 'help'
    }
}




