const { RichEmbed } = require("discord.js");
const { stripIndents } = require("common-tags");
const { getMember, formatDate } = {    formatDate: function(date) {
    return new Intl.DateTimeFormat('pt-BR').format(date)
},
getMember: function (message, toFind = '') {
    toFind = toFind.toLowerCase();

    let target = message.guild.members.get(toFind);

    if (!target && message.mentions.members)
        target = message.mentions.members.first();

    if (!target && toFind) {
        target = message.guild.members.find(member => {
            return member.displayName.toLowerCase().includes(toFind) ||
                member.user.tag.toLowerCase().includes(toFind)
        });
    }
    if (!target)
        target = message.member;

    return target;
},}
module.exports = {

    run: (client, message, args) => {
        const member = getMember(message, args.join(" "));

        // Member variables
        const joined = formatDate(member.joinedAt);
        const roles = member.roles
            .filter(r => r.id !== message.guild.id)
            .map(r => r).join(", ") || 'none';

        // User variables
        const created = formatDate(member.user.createdAt);

        const embed = new RichEmbed()
            .setFooter(member.displayName, member.user.displayAvatarURL)
            .setThumbnail(member.user.displayAvatarURL)
            .setColor(member.displayHexColor === '#000000' ? '#ffffff' : member.displayHexColor)

            .addField('Member information:', stripIndents`**> Nome:** ${member.displayName}
            **> Entrou em:** ${joined}
            **> Cargos:** ${roles}`, true)

            .addField('User information:', stripIndents`**> ID:** ${member.user.id}
            **> Apelido**: ${member.user.username}
            **> Tag**: ${member.user.tag}
            **> Criado em**: ${created}`)
            
            .setTimestamp()

        if (member.user.presence.game) 
            embed.addField('Jogando neste momento', stripIndents`**> Jogo/Sofware:** ${member.user.presence.game.name}`);

        message.channel.send(embed);
    },
    conf: {},

    help: {
        name: "userinfo",
        aliases: [ "user"],
        category: "info",
        description: "Retorna informações do usuario.",
        usage: "[username | id | mention]",
    }
}