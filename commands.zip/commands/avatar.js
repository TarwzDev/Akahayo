module.exports = {
  run: async (client, message, args) => {
  let user;
  if (message.mentions.users.size) {
    user = message.mentions.users.first();
  }
  else if (args.id) {
    user = await client.utils.fetchMember(message.guild, args.id);
    if (user) {
      user = user.user;
    }
  }
  if (!user) {
    user = message.author;
  }

  await message.channel.send({
    embed: {
      setcolor: client.colors,
      fields: [
        {
          name: 'Avatar',
          value: user.tag
        }
      ],
      image: {
        url: user.displayAvatarURL
      }
    }
  });

},
conf: {},

get help () {
  return {
    name: 'avatar',
    category: 'Info',
    description: 'Retorna o avatar do usuário',
    usage: `avatar`
  }
}
  }
